import './TaskCard.css';

const PRIORITY_CONFIG = {
  high: { label: 'High', color: 'red' },
  medium: { label: 'Medium', color: 'amber' },
  low: { label: 'Low', color: 'blue' }
};

const formatDate = (dateStr) => {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  const now = new Date();
  const diff = Math.ceil((d - now) / (1000 * 60 * 60 * 24));
  if (diff < 0) return { text: 'Overdue', overdue: true };
  if (diff === 0) return { text: 'Due today', today: true };
  if (diff === 1) return { text: 'Due tomorrow' };
  return { text: `Due ${d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}` };
};

export default function TaskCard({ task, onToggle, onEdit, onDelete, style }) {
  const priority = PRIORITY_CONFIG[task.priority] || PRIORITY_CONFIG.medium;
  const dueInfo = formatDate(task.dueDate);
  const isCompleted = task.status === 'completed';

  return (
    <div
      className={`task-card animate-in ${isCompleted ? 'task-done' : ''}`}
      style={style}
    >
      <div className="task-card-top">
        <button
          className={`task-check ${isCompleted ? 'checked' : ''}`}
          onClick={onToggle}
          title={isCompleted ? 'Mark as pending' : 'Mark as complete'}
        >
          {isCompleted && <span className="check-mark">✓</span>}
        </button>

        <div className="task-content">
          <h3 className={`task-title ${isCompleted ? 'strikethrough' : ''}`}>
            {task.title}
          </h3>
          {task.description && (
            <p className="task-desc">{task.description}</p>
          )}
        </div>
      </div>

      <div className="task-card-footer">
        <div className="task-meta">
          <span className={`priority-badge priority-${priority.color}`}>
            {priority.label}
          </span>
          {dueInfo && (
            <span className={`due-badge ${dueInfo.overdue ? 'overdue' : dueInfo.today ? 'today' : ''}`}>
              {dueInfo.overdue ? '⚠' : '◷'} {dueInfo.text}
            </span>
          )}
        </div>

        <div className="task-actions">
          <button className="task-btn edit-btn" onClick={onEdit} title="Edit">
            ✎
          </button>
          <button className="task-btn delete-btn" onClick={onDelete} title="Delete">
            ✕
          </button>
        </div>
      </div>
    </div>
  );
}
