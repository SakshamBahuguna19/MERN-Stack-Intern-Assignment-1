import { useState, useEffect, useRef } from 'react';
import toast from 'react-hot-toast';
import './TaskModal.css';

const defaultForm = { title: '', description: '', priority: 'medium', dueDate: '', status: 'pending' };

export default function TaskModal({ mode, task, onClose, onCreate, onUpdate }) {
  const isEdit = mode === 'edit';
  const [form, setForm] = useState(defaultForm);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const titleRef = useRef(null);

  useEffect(() => {
    if (isEdit && task) {
      setForm({
        title: task.title || '',
        description: task.description || '',
        priority: task.priority || 'medium',
        status: task.status || 'pending',
        dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : ''
      });
    }
    setTimeout(() => titleRef.current?.focus(), 100);
  }, [isEdit, task]);

  // Close on Escape
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  const validate = () => {
    const errs = {};
    if (!form.title.trim()) errs.title = 'Title is required';
    else if (form.title.trim().length < 3) errs.title = 'Title must be at least 3 characters';
    else if (form.title.trim().length > 100) errs.title = 'Title cannot exceed 100 characters';
    if (form.description.length > 500) errs.description = 'Description cannot exceed 500 characters';
    return errs;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setLoading(true);
    try {
      const payload = {
        title: form.title.trim(),
        description: form.description.trim(),
        priority: form.priority,
        status: form.status,
        dueDate: form.dueDate || null
      };
      if (isEdit) {
        await onUpdate(task._id, payload);
      } else {
        await onCreate(payload);
      }
    } catch (err) {
      const errs = err.response?.data?.errors;
      if (errs) {
        const fieldErrors = {};
        errs.forEach(e => { fieldErrors[e.path] = e.msg; });
        setErrors(fieldErrors);
      } else {
        toast.error(err.response?.data?.message || 'Something went wrong');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal animate-in" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">{isEdit ? 'Edit Task' : 'New Task'}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div className="modal-body">
            <div className="field-group">
              <label className="field-label">Title *</label>
              <input
                ref={titleRef}
                type="text"
                name="title"
                value={form.title}
                onChange={handleChange}
                placeholder="What needs to be done?"
                className={`field-input ${errors.title ? 'error' : ''}`}
                maxLength={100}
              />
              <div className="field-row-meta">
                {errors.title ? <span className="field-error">{errors.title}</span> : <span />}
                <span className="char-count">{form.title.length}/100</span>
              </div>
            </div>

            <div className="field-group">
              <label className="field-label">Description</label>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                placeholder="Add more details (optional)"
                className={`field-textarea ${errors.description ? 'error' : ''}`}
                rows={3}
                maxLength={500}
              />
              <div className="field-row-meta">
                {errors.description ? <span className="field-error">{errors.description}</span> : <span />}
                <span className="char-count">{form.description.length}/500</span>
              </div>
            </div>

            <div className="field-row-2">
              <div className="field-group">
                <label className="field-label">Priority</label>
                <select name="priority" value={form.priority} onChange={handleChange} className="field-select">
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>

              {isEdit && (
                <div className="field-group">
                  <label className="field-label">Status</label>
                  <select name="status" value={form.status} onChange={handleChange} className="field-select">
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>
              )}

              <div className="field-group">
                <label className="field-label">Due Date</label>
                <input
                  type="date"
                  name="dueDate"
                  value={form.dueDate}
                  onChange={handleChange}
                  className="field-input"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? <><span className="spinner" /> Saving...</> : isEdit ? 'Save Changes' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
