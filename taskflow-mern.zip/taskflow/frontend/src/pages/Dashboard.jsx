import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTasks } from '../hooks/useTasks';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';
import toast from 'react-hot-toast';
import './Dashboard.css';

const FILTERS = [
  { label: 'All', value: '' },
  { label: 'Pending', value: 'pending' },
  { label: 'Completed', value: 'completed' }
];

const PRIORITIES = [
  { label: 'All Priority', value: '' },
  { label: 'High', value: 'high' },
  { label: 'Medium', value: 'medium' },
  { label: 'Low', value: 'low' }
];

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { tasks, pagination, stats, loading, fetchTasks, createTask, updateTask, toggleTask, deleteTask } = useTasks();

  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState(null); // null | { mode: 'create'|'edit', task?: {} }
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const searchTimer = useRef(null);

  const load = useCallback((overrides = {}) => {
    fetchTasks({ search, status, priority, page, limit: 9, ...overrides });
  }, [fetchTasks, search, status, priority, page]);

  useEffect(() => { load(); }, [status, priority, page]);

  // Debounce search
  useEffect(() => {
    clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      setPage(1);
      load({ search, page: 1 });
    }, 400);
    return () => clearTimeout(searchTimer.current);
  }, [search]);

  const handleCreate = async (data) => {
    await createTask(data);
    setModal(null);
    load();
  };

  const handleUpdate = async (id, data) => {
    await updateTask(id, data);
    setModal(null);
    load();
  };

  const handleToggle = async (id) => {
    try {
      await toggleTask(id);
      load();
    } catch (err) {
      toast.error('Failed to update task');
    }
  };

  const handleDelete = async (id) => {
    await deleteTask(id);
    setDeleteConfirm(null);
    if (tasks.length === 1 && page > 1) setPage(p => p - 1);
    else load();
  };

  const handleFilterChange = (setter) => (val) => {
    setter(val);
    setPage(1);
  };

  return (
    <div className="dash-layout">
      {/* Sidebar */}
      <aside className="dash-sidebar">
        <div className="sidebar-top">
          <div className="sidebar-logo">
            <span className="sidebar-logo-mark">✦</span>
            <span className="sidebar-logo-text">TaskFlow</span>
          </div>

          <div className="sidebar-user">
            <div className="user-avatar">{user?.name?.[0]?.toUpperCase()}</div>
            <div className="user-info">
              <span className="user-name">{user?.name}</span>
              <span className="user-email">{user?.email}</span>
            </div>
          </div>

          <div className="sidebar-stats">
            <div className="stat-card stat-total">
              <span className="stat-num">{stats.total}</span>
              <span className="stat-label">Total</span>
            </div>
            <div className="stat-card stat-pending">
              <span className="stat-num">{stats.pending}</span>
              <span className="stat-label">Pending</span>
            </div>
            <div className="stat-card stat-done">
              <span className="stat-num">{stats.completed}</span>
              <span className="stat-label">Done</span>
            </div>
          </div>

          <button className="btn-new-task" onClick={() => setModal({ mode: 'create' })}>
            <span>+</span> New Task
          </button>

          <nav className="sidebar-nav">
            {FILTERS.map(f => (
              <button
                key={f.value}
                className={`nav-item ${status === f.value ? 'active' : ''}`}
                onClick={() => handleFilterChange(setStatus)(f.value)}
              >
                <span className={`nav-dot ${f.value || 'all'}`} />
                {f.label}
                {f.value === '' && <span className="nav-count">{stats.total}</span>}
                {f.value === 'pending' && <span className="nav-count">{stats.pending}</span>}
                {f.value === 'completed' && <span className="nav-count">{stats.completed}</span>}
              </button>
            ))}
          </nav>
        </div>

        <button className="btn-logout" onClick={logout}>
          <span>↩</span> Sign out
        </button>
      </aside>

      {/* Main */}
      <main className="dash-main">
        <div className="dash-header">
          <div>
            <h1 className="dash-title">
              {status === 'completed' ? 'Completed' : status === 'pending' ? 'Pending' : 'All Tasks'}
            </h1>
            <p className="dash-subtitle">
              {pagination ? `${pagination.total} task${pagination.total !== 1 ? 's' : ''}` : ''}
            </p>
          </div>

          <div className="dash-controls">
            <div className="search-wrap">
              <span className="search-icon">⌕</span>
              <input
                type="text"
                placeholder="Search tasks..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="search-input"
              />
              {search && (
                <button className="search-clear" onClick={() => setSearch('')}>×</button>
              )}
            </div>

            <select
              value={priority}
              onChange={e => handleFilterChange(setPriority)(e.target.value)}
              className="filter-select"
            >
              {PRIORITIES.map(p => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="tasks-loading">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="skeleton-card" style={{ animationDelay: `${i * 0.05}s` }} />
            ))}
          </div>
        ) : tasks.length === 0 ? (
          <div className="tasks-empty animate-in">
            <span className="empty-icon">◎</span>
            <p className="empty-title">
              {search ? 'No tasks match your search' : 'No tasks yet'}
            </p>
            <p className="empty-sub">
              {search ? 'Try different keywords' : 'Create your first task to get started'}
            </p>
            {!search && (
              <button className="btn-primary" onClick={() => setModal({ mode: 'create' })}>
                + Create Task
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="tasks-grid">
              {tasks.map((task, i) => (
                <TaskCard
                  key={task._id}
                  task={task}
                  style={{ animationDelay: `${i * 0.04}s` }}
                  onToggle={() => handleToggle(task._id)}
                  onEdit={() => setModal({ mode: 'edit', task })}
                  onDelete={() => setDeleteConfirm(task)}
                />
              ))}
            </div>

            {pagination && pagination.totalPages > 1 && (
              <div className="pagination">
                <button
                  className="page-btn"
                  disabled={!pagination.hasPrevPage}
                  onClick={() => setPage(p => p - 1)}
                >← Prev</button>

                <div className="page-nums">
                  {[...Array(pagination.totalPages)].map((_, i) => (
                    <button
                      key={i + 1}
                      className={`page-num ${page === i + 1 ? 'active' : ''}`}
                      onClick={() => setPage(i + 1)}
                    >{i + 1}</button>
                  ))}
                </div>

                <button
                  className="page-btn"
                  disabled={!pagination.hasNextPage}
                  onClick={() => setPage(p => p + 1)}
                >Next →</button>
              </div>
            )}
          </>
        )}
      </main>

      {/* Task Modal */}
      {modal && (
        <TaskModal
          mode={modal.mode}
          task={modal.task}
          onClose={() => setModal(null)}
          onCreate={handleCreate}
          onUpdate={handleUpdate}
        />
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div className="overlay" onClick={() => setDeleteConfirm(null)}>
          <div className="confirm-dialog animate-in" onClick={e => e.stopPropagation()}>
            <div className="confirm-icon">⚠</div>
            <h3>Delete task?</h3>
            <p>"{deleteConfirm.title}" will be permanently removed.</p>
            <div className="confirm-actions">
              <button className="btn-ghost" onClick={() => setDeleteConfirm(null)}>Cancel</button>
              <button className="btn-danger" onClick={() => handleDelete(deleteConfirm._id)}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
