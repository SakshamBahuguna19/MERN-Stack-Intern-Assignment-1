import { useState, useCallback } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

export const useTasks = () => {
  const [tasks, setTasks] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [stats, setStats] = useState({ total: 0, pending: 0, completed: 0 });
  const [loading, setLoading] = useState(false);

  const fetchTasks = useCallback(async (params = {}) => {
    setLoading(true);
    try {
      const { data } = await api.get('/tasks', { params });
      setTasks(data.tasks);
      setPagination(data.pagination);
      setStats(data.stats);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to fetch tasks');
    } finally {
      setLoading(false);
    }
  }, []);

  const createTask = async (taskData) => {
    const { data } = await api.post('/tasks', taskData);
    toast.success('Task created!');
    return data.task;
  };

  const updateTask = async (id, taskData) => {
    const { data } = await api.put(`/tasks/${id}`, taskData);
    toast.success('Task updated!');
    return data.task;
  };

  const toggleTask = async (id) => {
    const { data } = await api.patch(`/tasks/${id}/toggle`);
    return data.task;
  };

  const deleteTask = async (id) => {
    await api.delete(`/tasks/${id}`);
    toast.success('Task deleted');
  };

  return {
    tasks, pagination, stats, loading,
    fetchTasks, createTask, updateTask, toggleTask, deleteTask
  };
};
