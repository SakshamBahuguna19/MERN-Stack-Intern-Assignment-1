# TaskFlow — MERN Task Management App

A full-stack task management application built with MongoDB, Express.js, React.js, and Node.js.

![TaskFlow](https://img.shields.io/badge/Stack-MERN-7c6ff7?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)

---

## Features

### Core
- **User Authentication** — JWT-based register/login with bcrypt password hashing
- **Protected Routes** — Middleware-guarded API endpoints and React private routes
- **Full CRUD** — Create, read, update, delete tasks
- **Toggle Status** — Mark tasks as pending/completed with one click

### Bonus (All Implemented)
- **Search** — Real-time debounced search across title & description
- **Filter** — Filter by status (pending/completed) and priority (low/medium/high)
- **Pagination** — Server-side pagination (9 tasks/page)
- **Due Dates** — Set due dates with overdue/today visual indicators
- **Priority Levels** — High/Medium/Low with color-coded badges
- **Task Stats** — Live sidebar counters (total, pending, completed)

---

## Project Structure

```
taskflow/
├── backend/
│   ├── controllers/        # Business logic
│   │   ├── authController.js
│   │   └── taskController.js
│   ├── middleware/
│   │   └── auth.js         # JWT protect middleware
│   ├── models/
│   │   ├── User.js         # name, email, password
│   │   └── Task.js         # title, description, status, priority, dueDate, userId
│   ├── routes/
│   │   ├── auth.js
│   │   └── tasks.js
│   ├── .env.example
│   ├── package.json
│   └── server.js
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── TaskCard.jsx    # Task card with toggle/edit/delete
    │   │   └── TaskModal.jsx   # Create/edit modal with validation
    │   ├── context/
    │   │   └── AuthContext.jsx # Global auth state
    │   ├── hooks/
    │   │   └── useTasks.js     # Task operations hook
    │   ├── pages/
    │   │   ├── Login.jsx
    │   │   ├── Register.jsx
    │   │   └── Dashboard.jsx
    │   ├── utils/
    │   │   └── api.js          # Axios instance with interceptors
    │   ├── App.jsx
    │   └── main.jsx
    ├── index.html
    └── vite.config.js
```

---

## Setup Instructions

### Prerequisites
- Node.js v18+
- MongoDB (local or [MongoDB Atlas](https://www.mongodb.com/atlas))
- npm or yarn

### 1. Clone & install

```bash
git clone https://github.com/YOUR_USERNAME/taskflow.git
cd taskflow
```

### 2. Backend setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`:
```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/taskflow
JWT_SECRET=your_very_secret_key_here
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

```bash
npm run dev
# Server runs at http://localhost:5000
```

### 3. Frontend setup

```bash
cd ../frontend
npm install
npm run dev
# App runs at http://localhost:5173
```

---

## API Reference

### Auth Endpoints

| Method | Route | Description | Auth |
|--------|-------|-------------|------|
| POST | `/api/auth/register` | Create account | Public |
| POST | `/api/auth/login` | Login | Public |
| GET | `/api/auth/me` | Get profile | Private |

### Task Endpoints

| Method | Route | Description | Auth |
|--------|-------|-------------|------|
| GET | `/api/tasks` | Get all tasks (search/filter/paginate) | Private |
| POST | `/api/tasks` | Create task | Private |
| GET | `/api/tasks/:id` | Get single task | Private |
| PUT | `/api/tasks/:id` | Update task | Private |
| PATCH | `/api/tasks/:id/toggle` | Toggle status | Private |
| DELETE | `/api/tasks/:id` | Delete task | Private |

#### GET /api/tasks query params

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `search` | string | `''` | Search in title/description |
| `status` | string | `''` | `pending` or `completed` |
| `priority` | string | `''` | `low`, `medium`, or `high` |
| `page` | number | `1` | Page number |
| `limit` | number | `10` | Items per page (max 50) |
| `sortBy` | string | `createdAt` | Sort field |
| `sortOrder` | string | `desc` | `asc` or `desc` |

---

## Database Schemas

### User Schema
```js
{
  name:      String (required, 2–50 chars)
  email:     String (required, unique, validated)
  password:  String (required, hashed with bcrypt)
  createdAt: Date
  updatedAt: Date
}
```

### Task Schema
```js
{
  title:       String (required, 3–100 chars)
  description: String (max 500 chars)
  status:      Enum ['pending', 'completed'] (default: 'pending')
  priority:    Enum ['low', 'medium', 'high'] (default: 'medium')
  dueDate:     Date
  userId:      ObjectId (ref: User)
  createdAt:   Date
  updatedAt:   Date
}
```

---

## Security

- Passwords hashed with **bcryptjs** (12 salt rounds)
- **JWT** tokens expire in 7 days
- **Mongoose validation** on all inputs
- **express-validator** for request sanitization
- Tasks are strictly scoped to `userId` — users can only access their own tasks
- Global 401 interceptor auto-clears tokens and redirects to login

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, React Router 6, Axios, React Hot Toast |
| Build Tool | Vite 5 |
| Backend | Node.js, Express.js 4 |
| Database | MongoDB with Mongoose |
| Auth | JWT + bcryptjs |
| Validation | express-validator |

---

## Deployment

### Backend (Render/Railway)
1. Push to GitHub
2. Connect repo to Render
3. Set environment variables
4. Build command: `npm install`
5. Start command: `node server.js`

### Frontend (Vercel/Netlify)
1. Set `VITE_API_URL` in environment vars
2. Build command: `npm run build`
3. Output directory: `dist`
4. Update `vite.config.js` proxy for production → use env var

### MongoDB Atlas
1. Create cluster at mongodb.com/atlas
2. Get connection string
3. Set `MONGO_URI` in backend env vars

---

## Development Notes

- Vite proxy forwards `/api` requests to `localhost:5000` in dev
- All task routes are protected via `protect` middleware
- Frontend auto-redirects to `/login` on 401 via Axios interceptor
- Search is debounced 400ms to reduce API calls
- Pagination resets to page 1 on any filter/search change
